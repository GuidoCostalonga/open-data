# Open data internazionali: lotto 2

Questa consegna contiene solo nuovi dati rispetto al lotto 1. I file del primo lotto rimangono validi e non vengono sostituiti; la raccolta degli otto portali è ancora parziale.

## Contenuto

- **Excel dati:** 267, per 217 paesi/economie e 50 gruppi aggregati separati.
- **Banca Mondiale:** 100 indicatori aggiuntivi su agricoltura, energia, ambiente, acqua, digitale e istruzione; 1,755,600 righe, di cui 742,083 con numero.
- **Eurostat:** nascite, decessi e indicatori di fecondità territoriali; 186,562 righe, di cui 186,461 con numero, per 37 paesi/economie oltre agli aggregati.
- **Cumulativo:** 150 indicatori WDI e 5 dataset Eurostat nei lotti 1 e 2; 3,612,801 righe complessive nei due lotti.
- **Dimensioni:** tutti gli Excel e ZIP sono inferiori a 29.000.000 byte. Excel dati massimo: 3,726,535 byte.

Le serie mondiali provengono dalla [Banca Mondiale](https://data.worldbank.org/). I tre dataset Eurostat nuovi sono [nascite per territorio NUTS 3](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_r_births?lang=EN), [decessi per territorio NUTS 3](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_r_deaths?lang=EN) e [indicatori di fecondità per territorio NUTS 3](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_r_find3?lang=EN).

## Apertura e consultazione

Aprire prima `Open-data-internazionali_Indice-lotto-02.xlsx` e il foglio FILE per identificare l'archivio ZIP del paese. Estrarre gli Excel e usare i filtri dei fogli DATI_NAZIONALI_WB e DATI_EUROSTAT; i territori sono ordinati per codice all'interno del file del paese, non in file individuali per ogni regione.

Le eventuali parti numerate sono complementari e non ripetono i dati nazionali WB. CATALOGO_DATI distingue serie/dataset del lotto 1, nuove acquisizioni del lotto 2 e indicatori WDI ancora da acquisire; REGISTRO_SERIE contiene soltanto identità e conteggi cumulativi, non copie dei valori precedenti.

## Antiduplicazione

- **Identità:** fonte + database/dataset + tutte le dimensioni originali non temporali; ogni osservazione aggiunge il periodo.
- **Esclusioni:** non acquisiti nuovamente i 50 indicatori WDI né i due dataset Eurostat del lotto 1.
- **Risultato:** 37,248 identità di serie aggiunte; zero identità ripetute tra i lotti e zero osservazioni ripetute all'interno del lotto 2.
- **Limite del criterio:** non si eliminano dati solo perché numericamente uguali o tematicamente simili. Serie di fonti diverse mantengono identità e definizioni distinte e non vanno fuse automaticamente.
- **Conservazione:** verificati tramite SHA256 tutti i 268 Excel precedenti, senza modificarli.

## Interpretazione dei dati

Sono conservate tutte le annualità restituite dalle fonti, senza imputazioni. I null WB restano celle vuote; per Eurostat sono esportate le celle numeriche e quelle con stato, non tutte le combinazioni prive di dati e stato.

Gli intervalli temporali WB includono anche gli anni con righe nulle restituite dall'API. Primo/ultimo anno non significano necessariamente primo/ultimo anno con un'osservazione numerica.

La colonna Valore è numerica; Valore originale testo conserva la rappresentazione del numero scaricato. Le percentuali rimangono sulla scala originale, quindi 35 significa 35%, non 0,35; unità, note e stati devono essere consultati prima dei confronti.

I dati possono essere osservati, stimati, provvisori o modellizzati secondo la fonte. I livelli NUTS sono classificazioni statistiche, non equivalenze automatiche con regioni amministrative; codici storici e confini non sono armonizzati tra edizioni.

Non sommare indiscriminatamente anni, totali/componenti o livelli territoriali sovrapposti. Filtrare indicatore, unità, periodo e livello/versione geografica; medie, tassi e percentuali non sono additivi.

## Copertura residua e condizioni

Il dettaglio territoriale resta quello disponibile nei dataset Eurostat acquisiti e non copre ancora tutte le regioni del mondo. Restano altri indicatori/database World Bank, altri dataset Eurostat e le acquisizioni dirette da [data.europa.eu](https://data.europa.eu/), [UNdata](https://data.un.org/), [OCSE](https://www.oecd.org/en/data/datasets/oecd-DE.html), [FMI](https://data.imf.org/), [OMS/GHO](https://www.who.int/data/gho) e [FAOSTAT](https://www.fao.org/faostat).

Consultare le condizioni delle fonti e le eventuali eccezioni per singolo dataset. Non viene attribuita una licenza unica a tutta la consegna.

## Verifiche

Download nuovi: 2026-10-24T21:49:29Z / 2026-10-24T21:50:09Z. Anagrafica paesi e catalogo WDI sono riutilizzati dallo snapshot ufficiale del lotto 1; i nuovi dati hanno date proprie di download e aggiornamento.

Verificati integralmente identità, periodo e valore originale di ogni riga esportata tramite digest confrontati con le fonti. Ogni cella numerica è stata confrontata con il testo originale, con tolleranza relativa e assoluta di 1e-14 per la rappresentazione Excel; verificati null, conteggi, integrità ZIP, assenza di formule/celle di errore e dimensioni.
