# Open data internazionali: lotto 1

Questa è una consegna parziale di dati effettivi in Excel, non il completamento degli otto portali. Il perimetro concordato resta mondiale, con tutte le serie storiche, suddivisioni amministrative dove disponibili e tutti gli argomenti, da affrontare per lotti.

## Contenuto di questa consegna

- **Paesi/economie:** 217, secondo le classificazioni delle fonti; aggregati sovranazionali separati in 50 gruppi.
- **Excel di dati:** 268, oltre all'indice generale.
- **Banca Mondiale:** 50 indicatori WDI di demografia, salute, istruzione, ambiente, energia, acqua e servizi digitali; 877,800 righe, di cui 542,947 con valore numerico.
- **Eurostat:** due dataset integrali, densità e popolazione al 1 gennaio per età e sesso; 792,839 righe, di cui 792,781 con valore numerico.
- **Dettaglio territoriale:** disponibile per 37 paesi/economie in questo lotto; non costituisce ancora una copertura regionale mondiale.
- **Limite dimensionale:** ogni Excel e ciascun archivio ZIP è inferiore a 29.000.000 byte. L'Excel di dati più grande misura 6,045,723 byte.

Le serie WDI provengono dalla [Banca Mondiale](https://data.worldbank.org/); l'elenco completo delle 50 serie acquisite è filtrabile nell'indice. I due dataset Eurostat sono [densità della popolazione per territorio NUTS 3](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_r_d3dens?lang=EN) e [popolazione al 1 gennaio per grandi classi d'età, sesso e territorio NUTS 3](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_r_pjanaggr3?lang=EN).

## Come usare i file

Aprire prima `Open-data-internazionali_Indice-lotto-01.xlsx`, poi il foglio FILE. Individuare il paese e l'archivio ZIP corrispondente, estrarre il contenuto e aprire l'Excel del paese; il primo foglio LEGGIMI ne chiarisce la copertura.

I fogli DATI_NAZIONALI_WB contengono le serie nazionali in formato lungo: indicatore, anno e valore. I fogli DATI_EUROSTAT contengono i dati nazionali e territoriali, ordinati per codice e filtrabili per territorio, dataset, sesso, età e anno; non sono stati creati file separati per ogni singola regione.

Le parti numerate di uno stesso paese sono complementari. I dati WB sono soltanto nella prima parte, mentre i dati Eurostat sono ripartiti senza duplicazioni; il foglio FILE identifica tutte le parti da aprire.

## Precauzioni d'uso

- **Serie storiche:** nessun filtro temporale. I periodi dipendono da ciò che le API restituiscono; i conteggi includono righe senza valore dove previsto.
- **Valori mancanti:** null WB conservati vuoti, mai trasformati in zero; in Eurostat esportate le celle numeriche e quelle con uno stato, non l'intero prodotto cartesiano di celle vuote.
- **Stime:** le fonti contengono anche valori stimati o modellizzati. Consultare definizioni, note e stati; la legenda Eurostat completa è nel foglio DIZ_EUROSTAT dell'indice.
- **Precisione:** valori numerici Excel affiancati dal testo del numero scaricato. Percentuali conservate nella scala originale: 35 significa 35%, non 0,35.
- **Territori:** NUTS è una classificazione statistica, non un'equivalenza automatica con le regioni amministrative. Codici storici e denominazioni sono conservati, senza armonizzazione delle frontiere tra anni.
- **Aggregati:** conservati perché restituiti dalle API, ma distribuiti in archivi distinti dai paesi. Non devono essere sommati ai dati nazionali.
- **Doppi conteggi:** i dati Eurostat comprendono totali e componenti per sesso ed età, diversi livelli NUTS e codici storici. Prima di aggregare, filtrare dataset, anno, sesso, età e un solo livello/versione territoriale; non sommare densità né popolazioni di anni diversi.
- **Condizioni di riuso:** consultare le fonti e le eventuali eccezioni per singola serie; non viene attribuita una licenza unica a tutto il lotto.

## Copertura residua

Nel catalogo WDI acquisito figurano 1498 indicatori; 50 hanno dati inclusi in questo lotto, gli altri sono marcati Da acquisire nell'indice. Questo catalogo riguarda solo WDI e non tutti i database della Banca Mondiale; anche per Eurostat il lotto copre soltanto i due dataset specificati.

Restano da avviare le acquisizioni dirette da [data.europa.eu](https://data.europa.eu/), [UNdata](https://data.un.org/), [OCSE](https://www.oecd.org/en/data/datasets/oecd-DE.html), [FMI](https://data.imf.org/), [OMS/GHO](https://www.who.int/data/gho) e [FAOSTAT](https://www.fao.org/faostat). Un indicatore distribuito da WB può citare una di queste organizzazioni come fonte originaria, ma questo non significa che il relativo portale sia stato acquisito.

## Controlli e acquisizione

Acquisizione: 2026-10-24. Controllati tutti gli Excel di dati: integrità ZIP, conteggi delle righe e dei valori numerici per foglio confrontati con le risposte scaricate, assenza di formule e celle di errore Excel, nomi file e dimensioni; l'indice contiene hash SHA256 per riconoscere i file.

La richiesta dell'indicatore `SH.STA.OWAD.ZS` è stata rifiutata dall'API World Bank come Invalid value: nessuna riga è stata importata e nessun dato è stato ricostruito. Il problema resta registrato nel lotto.
